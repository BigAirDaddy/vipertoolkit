# config.py

# Add your actual API keys here
numverify_api_key = 'd7f5fb688dee8bfe11daf7966953e476'
access_key = '000a776376a506bfac3a25e123c671c8'
shodan_api_key = 'Nne8wolIevvQ6TH7VWbfYNAqaToPYNy3'
